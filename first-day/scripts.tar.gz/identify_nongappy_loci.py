#! /usr/bin/env python2.7

from string import maketrans
import sys
import os

f = open(sys.argv[1], "r")
#f1 = open(str(sys.argv[1])+".nogappy", "w")

#########parse fasta#########
content = f.readlines()
new=[]
for i in range(len(content)):
	new.append(content[i].strip())

count = 0
temp_seq=''
taxa = []
seqs_original = []
for i in range(len(new)):
	if '>' in new[i][0]:
		taxa.append(new[i])
		if count>0:
			seqs_original.append(temp_seq)
			temp_seq=''
	else:
		temp_seq=temp_seq + new[i]
		count = count +1
seqs_original.append(temp_seq)


################

seqs_trans_orig = [''.join(s) for s in zip(*seqs_original)]

intab = "N"
outtab = "-"
trantab = maketrans(intab, outtab)

seqs_trans_new = []
for i in range(len(seqs_trans_orig)):
	tmp = seqs_trans_orig[i].translate(trantab)
	if tmp.count("-") != 0 or tmp.count("N") != 0:
		count = count + 1 
gapcperc = float(count)/float(len(seqs_trans_orig))

print gapcperc

if gapcperc > float(sys.argv[2]):
	print sys.argv[1], "must be removed"
else:
	os.system("cp " + sys.argv[1] + " " + sys.argv[1] + ".keep")

f.close()

