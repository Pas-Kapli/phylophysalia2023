#! /usr/bin/env python2.7
import math
import sys
import itertools

f = open(sys.argv[1], 'r')
f2 = open(sys.argv[1] + "_filt.txt", 'w')

content = f.readlines()
keys = []
seqs = []
tmp = ""
count = 0

for i in range(len(content)):
	if ">" in content[i]:
		keys.append(content[i].strip()[1:])
		if count>0:
			seqs.append(tmp)
			tmp=""
	else:
		tmp = tmp + content[i].strip()
		count = count +1
seqs.append(tmp)
allen = len(tmp)

seqsd = {}
for i in range(len(keys)):
	seqsd[keys[i]] = seqs[i]

pairs = list(itertools.combinations(keys, 2))

# pairwise distances
pairdist = {}
for pair in pairs:
	count = 0
	allc = 0
	for i in range(allen):
		if seqsd[pair[0]][i] in "ACGTacgt"  and seqsd[pair[1]][i] in "ACGTacgt":
			allc = allc + 1
			tmp = len(''.join(set(seqsd[pair[0]][i] + seqsd[pair[1]][i])))
			if tmp > 1:
				count = count + 1
	if allc != 0 :
		pairdist[pair] = 1 - float(allc - count) / float(allc)
	else:
		pairdist[pair] = 0

# average pairwise distance per sample
taxdist = {}
for key in keys:
	sumd = 0
	count = 0
	for pair in pairdist:
		if key in pair:
			sumd = sumd + pairdist[pair]
			count = count + 1
#	print key, float(sumd)/float(count)
	taxdist[key] = float(sumd)/float(count)

# write filtered alignment
threshold = float(sys.argv[2])
#print threshold
count_taxa = 0
for key in keys:
	if taxdist[key] < threshold:
#		print sys.argv[1],key,taxdist[key]
		count_taxa = count_taxa + 1
	else:
		print sys.argv[1],key,taxdist[key]

for key in keys:
	if key=='Holaspis_guentheri' or key=='Mesalina_olivieri_S19' or taxdist[key] < threshold:
		f2.write(">" + key + "\n")
		f2.write(seqsd[key] + "\n")
	else:
		print sys.argv[1] + " " + key + " " + str(taxdist[key]) + "  removed"

f.close()
f2.close()
