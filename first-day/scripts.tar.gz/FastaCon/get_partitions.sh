tmp=1; for i in `cat fasta_order.txt`; do echo -n LG, ${i} = ${tmp}-; tmp=$(($(sed -n '2p' re-ordered_fasta/$i | wc -c) -2 +$tmp)); echo $tmp; tmp=$(($tmp+1)); done > partitions.txt
